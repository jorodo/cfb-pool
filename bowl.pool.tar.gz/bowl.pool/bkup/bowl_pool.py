#!/usr/bin/env python

import os
import sys
import numpy as np
import datetime
from operator import itemgetter, attrgetter
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import fitz.misc

class BowlPool():
    """
    Base class for organizing the Bowl Pool info and results.

    """

    def __init__(self, bowlResultsFileName, bowlPicksFileName, STPicksFileName,
                 bonusResultsFileName, bonusPicksFileName):
        """Initialize the bowl pool object.

        """
        self._bowlResultsFileName = bowlResultsFileName
        self._bowlPicksFileName = bowlPicksFileName
        self._STPicksFileName = STPicksFileName
        self._bonusResultsFileName = bonusResultsFileName
        self._bonusPicksFileName = bonusPicksFileName
        self._nBowls = None
        self._nBonus = None
        self._nTeams = None
        self._nResults = 0
        self._nBonusResults = 0
        self._teamList = []
        self._favPointsList = []
        self._favList = []
        self._dogList = []
        self._bowlList = []
        self._spreadList = []
        self._bonusList = []
        self._resultsList = []
        self._familyList = ['#Mama Bear', 'Admiral Akbar', 'A Real Quandre', 'Coin Toss', 'D-Bo', 'Eclipse',
                            'Gigi-Dawg', 'Mr. Gamblerer', 'Mrs. Gamblerer', 'Panda Bear', 'Mimi']
        self._rankingsList = []
        self._resultsVector = None
        self._bonusResultsList = []
        self._resultsMatrix = None
        self._picksMatrix = None
        self._bonusPicksMatrix = None
        self._favWinsMatrix = None
        self._dogWinsMatrix = None
        self._winsMatrix = None
        self._stbMatrix = None
        self._favPointsMatrix = None
        self._dogPointsMatrix = None
        self._pointsMatrix = None
        self._scoreMatrix = None
        self._bonusScoreMatrix = None
        self._scoreTotals = None
        self._sortedScoresList = []
        self._parseResultsFile()
        self._parseBonusFile()
        self._parseBowlPicksFile()
        self._parseSTPicksFile()
        self._parseBonusPicksFile()

    # ---- file parsing -------------------------------------------------

    def _parseResultsFile(self):
        """Load the bowl info and results from the text file."""
        lines = file(self._bowlResultsFileName).read().strip().split('\n')
        self._nBowls = len(lines)
        self._resultsVector = -1.*np.ones(self._nBowls)
        for i,line in enumerate(lines):
            line_data = line.split(',')
            self._bowlList.append(line_data[1])
            self._spreadList.append(float(line_data[2]))
            self._favList.append(line_data[3])
            self._dogList.append(line_data[4])
            self._favPointsList.append(float(line_data[5]))
            favWon = line_data[6]
            self._resultsList.append(int(favWon))
            self._resultsVector[i] = float(favWon)
            if float(favWon) >= 0: self._nResults += 1

    def _parseBowlPicksFile(self):
        lines = file(self._bowlPicksFileName).read().strip().split('\n')
        for team in lines[0].split(','):
            if team != '': self._teamList.append(team)
        self._nTeams = len(self._teamList)
        self._picksMatrix = np.zeros((self._nBowls, self._nTeams))

        for i,line in enumerate(lines[1:]):
            line_data = line.split(',')
            for j,pick in enumerate(line_data[:-1]):
                self._picksMatrix[i,j] = float(pick)

    def _parseSTPicksFile(self):
        lines = file(self._STPicksFileName).read().strip().split('\n')
        self._stbMatrix = np.zeros((self._nBowls, self._nTeams))

        for i, line in enumerate(lines[1:]):
            line_data = line.split(',')
            for j, pick in enumerate(line_data[:-1]):
                self._stbMatrix[i,j] = float(pick)

    def _parseBonusFile(self):
        """Load the bonus info the text file."""
        lines = file(self._bonusResultsFileName).read().strip().split('\n')
        self._nBonus = len(lines)
        for i,line in enumerate(lines):
            line_data = line.split(',')
            self._bonusList.append(line_data[1])
            bonusResult = line_data[2].strip()
            self._bonusResultsList.append(bonusResult)
            if bonusResult != 'None': self._nBonusResults += 1

    def _parseBonusPicksFile(self):
        lines = file(self._bonusPicksFileName).read().strip().split('\n')
        self._bonusPicksMatrix = []
        
        for i, line in enumerate(lines[1:]):
            line_data = line.split(',')
            self._bonusPicksMatrix.append([])
            for j, pick in enumerate(line_data[:-1]):
                self._bonusPicksMatrix[i].append(pick)

    # ---- end file parsing ---------------------------------------------

    # ---- calculate results of bowl pool -------------------------------

    def computeResults(self):
        """
        Compute the scores for each team in each bowl and store the result
        in the score matrix.


        """
        self._resultsMatrix = np.array([self._resultsVector,]*self._nTeams).transpose()
        self._favWinsMatrix = np.zeros(self._resultsMatrix.shape)
        self._dogWinsMatrix = np.zeros(self._resultsMatrix.shape)
        self._winsMatrix = np.zeros(self._resultsMatrix.shape)
        self._favPointsMatrix = np.zeros(self._resultsMatrix.shape)
        self._dogPointsMatrix = np.zeros(self._resultsMatrix.shape)
        self._pointsMatrix = np.zeros(self._resultsMatrix.shape)
        self._favPointsMatrix = np.array([np.array(self._favPointsList),]*self._nTeams).transpose()
        self._dogPointsList = [self._scoreBowl(i, (0,0), False) for i in xrange(self._nBowls)]
        self._dogPointsMatrix = np.array([np.array(self._dogPointsList),]*self._nTeams).transpose()
        self._pointsMatrix = self._resultsMatrix*self._favPointsMatrix \
                             + (1-self._resultsMatrix)*self._dogPointsMatrix
        self._favWinsMatrix = self._resultsMatrix * self._picksMatrix
        self._dogWinsMatrix = (1.-self._resultsMatrix)*(1.-self._picksMatrix)
        self._winsMatrix = self._favWinsMatrix + self._dogWinsMatrix
        self._scoreMatrix = self._winsMatrix*(self._pointsMatrix + self._stbMatrix)
        self._loadBonusScoreMatrix()
        self._scoreTotals = self._scoreMatrix[:self._nResults].sum(axis=0) \
                            + self._bonusScoreMatrix[:self._nBonusResults].sum(axis=0)
        # # ------- FIXME:  get picks list for these two teams ----
        # index = self._getTeamIndex('Just Guessin')
        # self._scoreTotals[index] = 0.
        # index = self._getTeamIndex('Still Guessin')
        # self._scoreTotals[index] = 0.
        # # -------------------------------------------------------
        self._rankTeams()
        # self._computeTrajectories()

    def _rankTeams(self):
        results_list = []
        for j in xrange(self._nTeams):
            teamName = self._teamList[j]
            results_list.append((teamName,self._scoreTotals[j]))

        self._sortedScoresList = sorted(results_list, key=itemgetter(1))
        self._sortedScoresList.reverse()
        rank = 1
        pvsScore = 0.
        self._rankingsList = [None for i in xrange(self._nTeams)]
        for i in xrange(self._nTeams):
            teamName = self._sortedScoresList[i][0]
            teamIndex = self._getTeamIndex(teamName)
            score = self._sortedScoresList[i][1]
            if i > 0:
                if score < pvsScore: rank = i+1
            self._rankingsList[teamIndex] = rank
            pvsScore = score

    # def _computeTrajectories(self):
    #     nResults = self._nResults
    #     pointsTrajectories = np.zeros((self._nResults, self._nTeams))
    #     rankingsTrajectories = np.zeros((self._nResults, self._nTeams))
    #     for i in xrange(1, self._nResults + 1):
    #         self._nResults = i
    #         self.computeResults()
    #         # # FIXME:  oops, broke this somehow
    #         # sys.stdout.flush()
    #         # print 'hi'
    #         # sys.exit()
    #         pointsTrajectories[i-1,:] = self._scoreTotals.copy()
    #         for j in xrange(self._nTeams):
    #             teamName = self._sortedScoresList[j][0]
    #             teamIndex = self._getTeamIndex(teamName)
    #             rank = self._rankingsList[teamIndex]
    #             rankingsTrajectories[i-1,teamIndex] = rank
                
    def _scoreBowl(self, bowlID, pick, favWon=None):
        """
        Return the points won for the given bowl.  Scoring function
        just follows the rules of the bowl pool.


        """
        if favWon==None: favWon = self._resultsList[bowlID]
        dogWon = not favWon
        points = 0.
        if favWon < 0: return 0.

        # the pick is whether or not the favorite won, given by pick[0]
        if favWon and pick[0]==1:
            favPoints = self._favPointsList[bowlID]
            points += favPoints
            # sure thing bowl
            if pick[1]==1: points += 1.
        elif dogWon and pick[0]==0:
            dogPoints = self._getDogPoints(bowlID)
            points += dogPoints
            # sure thing bowl
            if pick[1]==1: points += 1.

        return points

    def _getDogPoints(self,bowlID):
        """
        Return the bonus points for guessing a dog right.

        """
        spread = self._spreadList[bowlID]
        favPoints = self._favPointsList[bowlID]
        if spread >= 14.:
            dogPoints = 3.*favPoints
        elif spread >= 10.5:
            dogPoints = 2.5*favPoints
        elif spread >= 7.5:
            dogPoints = 2.*favPoints
        elif spread >= 4.:
            dogPoints = 1.5*favPoints
        elif spread >= 2.:
            dogPoints = 1.25*favPoints
        else:
            dogPoints = favPoints

        return dogPoints

    def _loadBonusScoreMatrix(self):
        self._bonusScoreMatrix = np.zeros((self._nBonus, self._nTeams))
        for i in xrange(self._nBonus):
            bonusResult = self._bonusResultsList[i]
            for j in xrange(self._nTeams):
                if self._bonusPicksMatrix[i][j] == self._bonusResultsList[i]:
                    self._bonusScoreMatrix[i][j] = 1.0

        return

    # ---- end calculate results ---------------------------------------

    # ---- file I/O ----------------------------------------------------

    def writeScoreTotals(self, printScoreTotals=False, outfilename='srv/results.txt'):
        fout = open(outfilename,'w')
        fout.write('*Last updated %s*\n\n'%datetime.datetime.now())
        for i in xrange(self._nTeams):
            teamName = self._sortedScoresList[i][0]
            score = self._sortedScoresList[i][1]
            teamIndex = self._getTeamIndex(teamName)
            rank = self._rankingsList[teamIndex]
            if printScoreTotals: print '%s. %s %s'%(rank, teamName, score)
            if teamName in self._familyList:
                fout.write('| %s. **%s %s**\n'%(rank, teamName, score))
            else:
                fout.write('| %s. %s %s\n'%(rank, teamName, score))
        fout.close()

    def writePicksTable(self, printScoreTotals=False, outfilename='srv/picks.txt'):
        maxFavLength = max([len(x) for x in self._favList])
        maxDogLength = max([len(x) for x in self._dogList])
        maxSchoolLength = max([maxFavLength, maxDogLength])
        maxTeamLength = max([len(x) for x in self._teamList])
        maxBowlLength = max([len(x) for x in self._bowlList])
        idLength = 1
        spreadLength = 1
        maxColLengths = [idLength,maxBowlLength]
        headerString = '"ID", "Bowl Name", "Favorite", "Underdog", "Spread"'
        maxWidthsString = '%s, %s, %s, %s, %s'%(idLength, maxBowlLength, maxFavLength,                                                            maxDogLength, spreadLength)
        picksMap = {}
        for j in xrange(self._nTeams):
            teamLength = len(self._teamList[j])
            maxPickLength = 0
            picksMap[j] = []
            for i in xrange(self._nBowls):
                if int(round(self._picksMatrix[i][j])):
                    pick = self._favList[i]
                else:
                    pick = self._dogList[i]
                picksMap[j].append(pick)
                if len(pick) > maxPickLength: maxPickLength = len(pick)
            maxColLength = max([teamLength, maxPickLength])
            maxColLengths.append(maxColLength)
            maxWidthsString += ', %s'%maxColLength
            headerString += ', %s'%self._teamList[j]
        fout = open(outfilename, 'w')
        fout.write('.. csv-table:: \n')
        fout.write('   :header: %s\n'%headerString)
        # fout.write('   :widths: %s\n'%(maxWidthsString))
        # fout.write('   :stub-columns: 5\n')
        fout.write('\n')
        for i in xrange(self._nBowls):
            fout.write('   "%s", "%s", "%s", "%s", "%s"'%(i+1, self._bowlList[i],
                                                          self._favList[i],
                                                          self._dogList[i],
                                                          self._spreadList[i]))
            for j in xrange(self._nTeams):
                fout.write(', "%s"'%picksMap[j][i])
            fout.write('\n')
        # fout.write('=========  ' +  '='*colWidth + '\n')
        # fout.write('=========  ' +  '='*colWidth + '\n')
        # fout.write('Bowl ID    ')
        # fout.write('=========  ' +  '='*colWidth + '\n')
        # for i in xrange(self._nBowls):
        #     fout.write('%s  %s \n'%(i+1, self._bowlList[i]))
        # fout.write('=========  ' +  '='*colWidth + '\n')
        fout.close()
            
    # ---- end file I/O ------------------------------------------------

    # ---- utilities ---------------------------------------------------
    
    def _getTeamIndex(self, teamName):
        return self._teamList.index(teamName)

    def listBowlData(self):
        """Print out all the bowl info.

        """
        print 'ID, Name, Spread, Favorite, Dog, Result'
        print '~'*40
        for i in xrange(self._nBowls):
            print i, self._bowlList[i], self._spreadList[i], self._favList[i], \
                self._dogList[i], self._resultsList[i]

    def printPicks(self, teamName, printResults=True):
        """
        Print the picks for a given team.

        """
        j = self._getTeamIndex(teamName)

        nameStr = teamName
        if printResults: nameStr += '  (%s)'%self._scoreTotals[j]
        print nameStr
        print '~'*20

        for i in xrange(self._nBowls):
            teamstr = ''
            if int(round(self._picksMatrix[i][j])):
                teamstr += '(STB) ' if int(round(self._stbMatrix[i][j])) else ''
                teamstr += self._favList[i]
            else:
                teamstr += '(STB) ' if int(round(self._stbMatrix[i][j])) else ''
                teamstr += self._dogList[i]
            if self._resultsVector[i] >=0 and printResults:
                teamstr += '  (%s)'%str(self._scoreMatrix[i][j])
            print '%s.'%i, teamstr

        for i in xrange(self._nBonus):
            bonusstr = '%s %s'%(self._bonusList[i],
                                self._bonusPicksMatrix[i][j])
            if self._bonusResultsList[i] != 'None' and printResults:
                bonusstr += '  (%s)'%str(self._bonusScoreMatrix[i][j])
            print 'B%s.'%i, bonusstr

    def checkSTBowls(self):
        """
        Print out any teams that don't have three sure thing bowls.

        """
        stbSums = self._stbMatrix.sum(axis=0)
        if (stbSums != 3.0).any():
            print 'The following teams do not have 3 sure thing bowls:'
            for i in np.where(stbSums != 3.0)[0]:
                print i, self._teamList[i], stbSums[i]

    # ---- end utilities -------------------------------------------------

    # ---- plots and analysis -------------------------------------------------

    def plotScoresHistogram(self, nbins=30):
        """
        Plot the distribution of team scores.

        """
        # TODO:  add points and for a list of teams
        fig = plt.figure()
        ax = fig.add_subplot(111)
        ax.hist(self._scoreTotals,bins=nbins)
        ax.set_xlabel('Total Points')
        ax.set_ylabel('Number of Teams')
        fig.savefig('srv/scoresHistogram.png')

    # def plotTrajectories(self, teamList=self._familyList):
    #     """
    #     Plot the trajectory of teams' points and rankings over the bowl games.
    # 
    #     """
    #             
    #     teamIndexes = [self._getTeamIndex(x) for x in teamList]
    #     
    #     fig = plt.figure()
    #     ax = fig.add_subplot(111)
    #     x = np.arange(nResults)
    #     for index in teamIndexes:
    #         ax.plot(x, pointsTrajectories[:,index])
    #         ax.set_xlabel('Bowl Game Number')
    #         ax.set_ylabel('Total Points')
    #         fig.savefig('srv/pointsTrajectories.png')
    #         fig.clf()
    # 
    #     # TODO:  add labels and stuff to these plots
    # 
    #     fig = plt.figure()
    #     ax = fig.add_subplot(111)
    #     x = np.arange(nResults)
    #     for i, index in enumerate(teamIndexes):
    #         teamName = self._familyList[i]
    #         ax.plot(x, rankingsTrajectories[:,index])
    #         ax.set_xlabel('Bowl Game Number')
    #         ax.set_ylabel('Ranking')
    #         fig.gca().invert_yaxis()
    #         fig.savefig('srv/rankingsTrajectories.png')
    #         fig.clf()
    # 
    #     self._nResults = nResults

    # ---- end plots and analysis ---------------------------------------------

    
if __name__ == "__main__":

    bowlResultsFileName = "input/bowlResults.csv"
    bowlPicksFileName = "input/bowlPicks.csv"
    STPicksFileName = "input/STPicks.csv"
    bonusResultsFileName = "input/bonusResults.csv"
    bonusPicksFileName = "input/bonusPicks.csv"
    B = BowlPool(bowlResultsFileName, bowlPicksFileName, STPicksFileName,
                 bonusResultsFileName, bonusPicksFileName)
    B.computeResults()
    B.writePicksTable()
    # B.writeScoreTotals(True)
    # B.plotTrajectories()
    # B.listBowlData()
    # B.printPicks('Mr. Gamblerer')
    # nbins = 10
    # B.plotScoresHistogram(nbins)
    # B.checkSTBowls()

